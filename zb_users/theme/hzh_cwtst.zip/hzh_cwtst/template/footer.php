<div class="footer">
	<div class="box">

	  <div class="footer-copy">
		<p>版权所有：<a href="http://www.cwtstour.com/" title="长春新闻信息网" >长春新闻信息网</a> 网站备案号：浙ICP备12333367号  Copyright©1998-2020 互联网新闻信息许可证 编号：22120180088</p>
	  </div>
	</div>
  </div>
  <style>
	.footer-copy p {
    line-height: 28px;
    color: #999;
}
  </style>