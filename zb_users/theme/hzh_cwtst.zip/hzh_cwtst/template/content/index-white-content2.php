<div class="index-white-bg">
    <ul>
    {foreach [1,2,3] as $i}
        {template:content/components/content2Item}
     {/foreach}
</ul>
</div>
