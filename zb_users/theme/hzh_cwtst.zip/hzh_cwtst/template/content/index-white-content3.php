<div class="index-white-bg">
    <div class="index-head">
	  <h2>长春新闻网介绍</h2>
	</div>
    <div class="index-body">
      <p>长春新闻信息网重点关注长春城市建设及发展，同时提供国际、国内及省内重要的新闻信息，是对外宣传长春、服务长春、推介长春的重要网络窗口。24小时全面滚动播报,关注长春人的生活状态和生存环境,更全面更便捷的帮助群众了解<a href="http://www.cwtstour.com/" title="长春新闻">长春新闻</a>，本地的民生新闻、人文情怀、经济发展等信息。</p>
    </div>
</div>


<style>
.index-body {
    text-align: justify;
    line-height: 26px;
    font-size: 15px;
    color: #555;
}
</style>