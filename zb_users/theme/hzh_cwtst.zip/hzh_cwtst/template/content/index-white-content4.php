<div class="index-white-bg">
    <div class="index-head">
	  <h2>友情链接</h2>
	</div>
    <div class="links">
	    <a class="link-a" href="#" target="_blank">网站地图</a> <a class="link-a" href="#" target="_blank">百度地图</a> 
    </div>
</div>


<style>
.index-body {
    text-align: justify;
    line-height: 26px;
    font-size: 15px;
    color: #555;
}
.links {
    overflow: hidden;
}

.links a {
    display: block;
    float: left;
    margin-right: 30px;
    color: #999;
    line-height: 34px;
}
</style>