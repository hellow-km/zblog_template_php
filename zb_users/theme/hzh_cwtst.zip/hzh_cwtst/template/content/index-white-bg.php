
     {foreach [1,2] as $i}
        {template:content/index-white-content1}
     {/foreach}

     {foreach [1,2] as $i}
        {template:content/index-white-content2}
     {/foreach}

    {template:content/index-white-content3}

      {template:content/index-white-content4}