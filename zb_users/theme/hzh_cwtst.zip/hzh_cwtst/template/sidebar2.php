

<div id="sidebar-box2">
    <el-divider content-position="left">最近文章</el-divider>
    <div class="side-previous">
        {module:previous}
    </div>
</div>

<script type="module">
new Vue({
    el: "#sidebar-box2",
})
</script>