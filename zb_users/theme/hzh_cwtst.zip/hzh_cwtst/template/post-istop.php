{* Template Name:列表页单条置顶文章 *}

<div class="week-click-one">
	   <h2><a href="{$article.Url}" title="{$article.Title}">{$article.Title}</a></h2>
		<p>{$article.Intro}<a href="{$article.Url}">详细&gt;&gt;</a></p>
	  </div>