<div class="top-desc">
<p>1234567</p>
<div class="cc-page-header">
    <div class="page-logo">
        <img height="50" width="166" src="https://www.cwtstour.com//news_web/uploads/allimg/230911/1-2309111601415B.png" alt="">
    </div>
    <div class="nav-box">
        {module:navbar}
    </div>
</div>
</div>

<style>
    .page-logo{
        cursor: pointer;
        margin-top: 15px
    }
    .cc-page-header{
        Position: relative;
    margin: 0 auto;
    height: 65px;
    width: 1200px;
    display: flex;
    align-items: center;
    }

    .top-desc p {
    color: #999;
    font-size: 13px;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
}
.nav-box{
     margin-top: 15px
}
</style>

