addEventListener("DOMContentLoaded", () => {
    let navBars = document.querySelectorAll(".navbar-item");
    navBars.forEach((navLi) => {
        let navA = navLi.getElementsByTagName("a");
        if (navA[0]) {
            if (navA[0].href == location.href) {
                navLi.classList.add("navbar-item-active");
            }
        }
    });
});
